<?php
//messages
$lang['subscribe:success']			=	'It worked';
$lang['subscribe:error']			=	'It didn\'t work';
$lang['subscribe:no_items']			=	'No Items';

//page titles
$lang['subscribe:create']			=	'Create Item';

//labels
$lang['subscribe:name']				=	'Name';
$lang['subscribe:email']			=	'Email';
$lang['subscribe:manage']			=	'Manage';
$lang['subscribe:item_list']		=	'Item List';
$lang['subscribe:view']				=	'View';
$lang['subscribe:edit']				=	'Edit';
$lang['subscribe:delete']			=	'Delete';

//buttons
$lang['subscribe:custom_button']	=	'Custom Button';
$lang['subscribe:items']			=	'Items';
?>