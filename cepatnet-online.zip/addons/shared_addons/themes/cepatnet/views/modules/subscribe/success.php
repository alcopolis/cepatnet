<div class="clearfix" style="margin:120px auto 0 auto; width:75%; padding:20px;">
    <h1>Pendaftaran Berhasil</h1>
    <p>Terima kasih. Data pendaftaran berlangganan Anda sudah masuk ke database kami. Tim CS kami akan segera menghubungi Anda untuk proses selanjutnya.</p>
    <p><a href="{{url:site}}">&laquo; Back to Home</a></p>	
</div>	