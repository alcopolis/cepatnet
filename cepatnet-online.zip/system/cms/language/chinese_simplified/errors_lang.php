<?php
/**
 * Chinese Simpplified translation.
 *
 * @author		Kefeng DENG
 * @package		PyroCMS
 * @subpackage 	-
 * @category	-
 * @link		http://pyrocms.com
 * @date		2012-06-22
 * @version		1.0
 */
// Error 404
$lang['error_404_title'] 			= '找不到頁面';
$lang['error_404_message'] 			= '我們无法找到您要查看的頁面，請  <a href="%s">点击这里</a> 回到首页。';

// Database
$lang['error_invalid_db_group'] 	= '数据库目前正尝试使用的设定 "%s" 是不正確的。';

?>