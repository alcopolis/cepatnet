<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "The %s field may only contain alpha-numeric characters, underscores, dots and dashes.";
$lang['decimal']				= "The %s field must contain only decimal numbers.";
$lang['csrf_bad_token']			= "Invalid CSRF Token";

/* End of file extra_validation_lang.php */