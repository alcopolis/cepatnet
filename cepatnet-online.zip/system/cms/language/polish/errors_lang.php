<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Błąd 404: Nie znaleziono strony';
$lang['error_404_message'] = 'Przepraszamy. Strona, której szukasz nie została odnaleziona. Kliknij <a href="%s">tutaj</a>, aby przejść do strony głównej.';

// Database
$lang['error_invalid_db_group'] = 'Baza danych próbuje użyć nieprawidłowej konfiguracji grupy "%s".';

/* End of file errors_lang.php */