<?php defined('BASEPATH') OR exit('No direct script access allowed');

$lang['alpha_dot_dash']			= "Trường %s chỉ được nhập chữ hoặc số, dấu gạch dưới, dấu chấm và dấu gạch ngang.";
$lang['decimal']				= "Trường %s chỉ được nhập số.";
$lang['csrf_bad_token']			= "Sai CSRF Token";

/* End of file extra_validation_lang.php */