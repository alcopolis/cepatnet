<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Página não encontrada';
$lang['error_404_message'] = 'Não conseguimos encontrar a página que está a procurar, por favor, clique <a href="%s">aqui</a> para retornar à página inicial.';

// Database
$lang['error_invalid_db_group'] = 'A base de dados está a tentar utilizar um grupo de configurações inválido: "%s".';

/* End of file errors_lang.php */