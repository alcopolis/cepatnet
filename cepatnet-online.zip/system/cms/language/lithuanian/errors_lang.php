<?php defined('BASEPATH') OR exit('No direct script access allowed');

// Error 404
$lang['error_404_title'] = 'Toks puslapis nerastas';
$lang['error_404_message'] = 'Negalime surasti tokio puslapio, spauskite <a href="%s">čia</a> kad patektumėte į pagrindinį puslapį.';

// Database
$lang['error_invalid_db_group'] = 'Grupė "%s" duomenų bazė netinkamos konfigūracijos.';

/* End of file errors_lang.php */